result environment
